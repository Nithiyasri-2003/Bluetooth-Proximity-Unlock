# Bluetooth Proximity Unlock Project

This Arduino-based project unlocks a device when a specific Bluetooth signal is received from an authorized phone. It uses the HC-05 Bluetooth module and communicates via SoftwareSerial.

## Features
- Unlocks system when 'U' command is received via Bluetooth
- Locks back after 5 seconds automatically
- Can be connected to a relay or LED as an output

## Components Used
- Arduino Uno
- HC-05 Bluetooth Module
- Relay module or LED
- Jumper wires
- Smartphone with Bluetooth terminal app

## Circuit Connections
- HC-05 TX -> Arduino pin 10
- HC-05 RX -> Arduino pin 11 (via voltage divider)
- Output device (LED/Relay) -> Arduino pin 7

## Usage
1. Upload the code to Arduino using Arduino IDE.
2. Pair HC-05 with your phone.
3. Use a Bluetooth terminal app to send the character `U`.
4. The device will unlock for 5 seconds.

## Status
Fully functional.
